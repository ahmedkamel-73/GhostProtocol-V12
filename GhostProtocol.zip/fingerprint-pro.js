// نظام البصمة الرقمية المتقدم
class AdvancedFingerprint {
    constructor() {
        this.fingerprint = {};
        this.rotationInterval = null;
        this.init();
    }

    init() {
        this.generateFingerprint();
        this.applyFingerprint();
        this.startRotation();
        this.setupProtection();
    }

    generateFingerprint() {
        this.fingerprint = {
            // معلومات النظام الأساسية
            userAgent: this.getRandomUserAgent(),
            platform: this.getRandomPlatform(),
            languages: this.getRandomLanguages(),
            appVersion: navigator.appVersion,
            
            // معلومات الشاشة
            screen: {
                width: this.getRandomScreenWidth(),
                height: this.getRandomScreenHeight(),
                colorDepth: 24,
                pixelDepth: 24,
                availWidth: this.getRandomScreenWidth(),
                availHeight: this.getRandomScreenHeight()
            },
            
            // معلومات الوقت
            timezone: this.getRandomTimezone(),
            timezoneOffset: new Date().getTimezoneOffset(),
            
            // معلومات الأجهزة
            hardwareConcurrency: this.getRandomCpuCores(),
            deviceMemory: this.getRandomMemory(),
            maxTouchPoints: navigator.maxTouchPoints || 0,
            
            // معلومات الاتصال
            connection: this.getRandomConnection(),
            
            // معلومات الوسائط
            mediaDevices: this.generateMediaDevices(),
            
            // معلومات الرسوميات
            webgl: this.generateWebGLInfo(),
            
            // معلومات الصوت
            audio: this.generateAudioInfo(),
            
            // إعدادات أخرى
            doNotTrack: navigator.doNotTrack || 'unspecified',
            cookieEnabled: navigator.cookieEnabled,
            onLine: navigator.onLine,
            
            // معلومات إضافية
            plugins: this.generatePlugins(),
            mimeTypes: this.generateMimeTypes(),
            
            // توقيتات عشوائية
            performanceTiming: this.generatePerformanceTiming(),
            
            // معرّف فريد
            sessionId: this.generateSessionId(),
            fingerprintId: this.generateFingerprintId()
        };
    }

    getRandomUserAgent() {
        const agents = [
            // Chrome Windows
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
            
            // Chrome Mac
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            
            // Firefox Windows
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0',
            
            // Firefox Mac
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:121.0) Gecko/20100101 Firefox/121.0',
            
            // Safari
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
            
            // Edge
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0'
        ];
        
        return agents[Math.floor(Math.random() * agents.length)];
    }

    getRandomPlatform() {
        const platforms = [
            'Win32', 'Win64', 'MacIntel', 'Linux x86_64',
            'Linux armv8l', 'Linux armv7l', 'Linux i686'
        ];
        
        return platforms[Math.floor(Math.random() * platforms.length)];
    }

    getRandomLanguages() {
        const languageSets = [
            ['ar-SA', 'ar', 'en-US', 'en'],
            ['en-US', 'en', 'es', 'fr'],
            ['fr-FR', 'fr', 'en-US', 'en'],
            ['de-DE', 'de', 'en-US', 'en'],
            ['en-GB', 'en', 'fr', 'de']
        ];
        
        return languageSets[Math.floor(Math.random() * languageSets.length)];
    }

    getRandomScreenWidth() {
        const widths = [1920, 1366, 1536, 1440, 1280, 1600, 1680];
        return widths[Math.floor(Math.random() * widths.length)];
    }

    getRandomScreenHeight() {
        const heights = [1080, 768, 864, 900, 720, 900, 1050];
        return heights[Math.floor(Math.random() * heights.length)];
    }

    getRandomTimezone() {
        const timezones = [
            'America/New_York',
            'Europe/London', 
            'Asia/Dubai',
            'Asia/Riyadh',
            'Europe/Paris',
            'Asia/Tokyo',
            'Australia/Sydney',
            'Asia/Shanghai',
            'Europe/Berlin',
            'America/Los_Angeles'
        ];
        
        return timezones[Math.floor(Math.random() * timezones.length)];
    }

    getRandomCpuCores() {
        const cores = [2, 4, 6, 8, 12, 16];
        return cores[Math.floor(Math.random() * cores.length)];
    }

    getRandomMemory() {
        const memory = [4, 8, 16, 32];
        return memory[Math.floor(Math.random() * memory.length)];
    }

    getRandomConnection() {
        const connections = [
            { effectiveType: '4g', rtt: 50, downlink: 10, saveData: false },
            { effectiveType: '3g', rtt: 150, downlink: 3, saveData: false },
            { effectiveType: 'wifi', rtt: 30, downlink: 20, saveData: false }
        ];
        
        return connections[Math.floor(Math.random() * connections.length)];
    }

    generateMediaDevices() {
        return {
            audioinput: { devices: 1, labels: ['Default', 'Microphone'] },
            videoinput: { devices: 1, labels: ['Integrated Camera'] },
            audiooutput: { devices: 1, labels: ['Default', 'Speakers'] }
        };
    }

    generateWebGLInfo() {
        const vendors = [
            'Google Inc. (NVIDIA)',
            'Google Inc. (Intel)',
            'Google Inc. (AMD)',
            'Mozilla (NVIDIA)',
            'Apple (Apple GPU)'
        ];
        
        const renderers = [
            'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0)',
            'ANGLE (Intel, Intel(R) UHD Graphics 630 Direct3D11 vs_5_0 ps_5_0)',
            'ANGLE (AMD, AMD Radeon RX 6700 XT Direct3D11 vs_5_0 ps_5_0)',
            'Apple GPU (Apple M1 Pro)',
            'Mozilla (GeForce GTX 1660)'
        ];
        
        return {
            vendor: vendors[Math.floor(Math.random() * vendors.length)],
            renderer: renderers[Math.floor(Math.random() * renderers.length)],
            version: 'WebGL 2.0',
            shadingLanguage: 'WebGL GLSL ES 3.00'
        };
    }

    generateAudioInfo() {
        const contexts = ['AudioContext', 'webkitAudioContext', 'mozAudioContext'];
        const sampleRates = [44100, 48000, 96000];
        
        return {
            context: contexts[Math.floor(Math.random() * contexts.length)],
            sampleRate: sampleRates[Math.floor(Math.random() * sampleRates.length)],
            channelCount: 2
        };
    }

    generatePlugins() {
        const pluginSets = [
            [
                { name: 'Chrome PDF Plugin', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
                { name: 'Chrome PDF Viewer', filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai', description: '' },
                { name: 'Native Client', filename: 'internal-nacl-plugin', description: '' }
            ],
            [
                { name: 'Widevine Content Decryption Module', filename: 'widevinecdmadapter.plugin', description: 'Enables Widevine licenses for playback of HTML audio/video content.' },
                { name: 'Shockwave Flash', filename: 'libpepflashplayer.so', description: 'Shockwave Flash 32.0' }
            ],
            [
                { name: 'Microsoft Office', filename: 'npmsoplugin.dll', description: 'Microsoft Office Plug-in for Netscape Navigator' }
            ]
        ];
        
        return pluginSets[Math.floor(Math.random() * pluginSets.length)];
    }

    generateMimeTypes() {
        const mimeTypeSets = [
            [
                { type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format' },
                { type: 'text/plain', suffixes: 'txt', description: 'Plain Text' },
                { type: 'application/x-google-chrome-pdf', suffixes: 'pdf', description: 'PDF Document' }
            ],
            [
                { type: 'application/x-shockwave-flash', suffixes: 'swf', description: 'Shockwave Flash' },
                { type: 'application/x-google-chrome-pdf', suffixes: 'pdf', description: 'PDF Document' },
                { type: 'application/x-nacl', suffixes: '', description: 'Native Client Executable' },
                { type: 'application/x-pnacl', suffixes: '', description: 'Portable Native Client Executable' }
            ]
        ];
        
        return mimeTypeSets[Math.floor(Math.random() * mimeTypeSets.length)];
    }

    generatePerformanceTiming() {
        const now = performance.now();
        return {
            navigationStart: now - 5000,
            domLoading: now - 4000,
            domInteractive: now - 3000,
            domContentLoaded: now - 2000,
            loadEventStart: now - 1000,
            loadEventEnd: now
        };
    }

    generateSessionId() {
        return 'sess_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    generateFingerprintId() {
        const components = [
            this.fingerprint.userAgent,
            this.fingerprint.screen.width,
            this.fingerprint.screen.height,
            this.fingerprint.timezone,
            this.fingerprint.hardwareConcurrency
        ];
        
        const str = components.join('|');
        let hash = 0;
        
        for (let i = 0; i < str.length; i++) {
            hash = ((hash << 5) - hash) + str.charCodeAt(i);
            hash = hash & hash;
        }
        
        return 'fp_' + Math.abs(hash).toString(36);
    }

    applyFingerprint() {
        // تطبيق User Agent
        Object.defineProperty(navigator, 'userAgent', {
            get: () => this.fingerprint.userAgent,
            configurable: false
        });
        
        Object.defineProperty(navigator, 'appVersion', {
            get: () => this.fingerprint.appVersion,
            configurable: false
        });
        
        // تطبيق Platform
        Object.defineProperty(navigator, 'platform', {
            get: () => this.fingerprint.platform,
            configurable: false
        });
        
        // تطبيق Languages
        Object.defineProperty(navigator, 'languages', {
            get: () => this.fingerprint.languages,
            configurable: false
        });
        
        // تطبيق معلومات الشاشة
        this.spoofScreenProperties();
        
        // تطبيق معلومات الأجهزة
        this.spoofHardwareProperties();
        
        // تطبيق معلومات الاتصال
        this.spoofConnectionProperties();
        
        // تطبيق معلومات الوسائط
        this.spoofMediaDevices();
        
        // تطبيق معلومات WebGL
        this.spoofWebGLProperties();
        
        // تطبيق معلومات الصوت
        this.spoofAudioProperties();
        
        // تطبيق Plugins و MimeTypes
        this.spoofPluginProperties();
        
        console.log('✅ تم تطبيق بصمة المتصفح المتقدمة');
    }

    spoofScreenProperties() {
        const screenProps = [
            'width', 'height', 'colorDepth', 'pixelDepth', 
            'availWidth', 'availHeight'
        ];
        
        screenProps.forEach(prop => {
            Object.defineProperty(screen, prop, {
                get: () => this.fingerprint.screen[prop],
                configurable: false
            });
        });
    }

    spoofHardwareProperties() {
        if ('hardwareConcurrency' in navigator) {
            Object.defineProperty(navigator, 'hardwareConcurrency', {
                get: () => this.fingerprint.hardwareConcurrency,
                configurable: false
            });
        }
        
        if ('deviceMemory' in navigator) {
            Object.defineProperty(navigator, 'deviceMemory', {
                get: () => this.fingerprint.deviceMemory,
                configurable: false
            });
        }
        
        if ('maxTouchPoints' in navigator) {
            Object.defineProperty(navigator, 'maxTouchPoints', {
                get: () => this.fingerprint.maxTouchPoints,
                configurable: false
            });
        }
    }

    spoofConnectionProperties() {
        if ('connection' in navigator) {
            const conn = navigator.connection;
            if (conn) {
                ['effectiveType', 'rtt', 'downlink', 'saveData'].forEach(prop => {
                    if (prop in conn) {
                        Object.defineProperty(conn, prop, {
                            get: () => this.fingerprint.connection[prop],
                            configurable: false
                        });
                    }
                });
            }
        }
    }

    spoofMediaDevices() {
        if ('mediaDevices' in navigator) {
            const originalEnumerateDevices = navigator.mediaDevices.enumerateDevices;
            
            navigator.mediaDevices.enumerateDevices = async () => {
                const devices = [];
                
                // أجهزة الإدخال الصوتي
                this.fingerprint.mediaDevices.audioinput.labels.forEach(label => {
                    devices.push({
                        deviceId: 'default',
                        kind: 'audioinput',
                        label: label,
                        groupId: 'audio-input-group'
                    });
                });
                
                // أجهزة إدخال الفيديو
                this.fingerprint.mediaDevices.videoinput.labels.forEach(label => {
                    devices.push({
                        deviceId: 'default',
                        kind: 'videoinput',
                        label: label,
                        groupId: 'video-input-group'
                    });
                });
                
                // أجهزة إخراج الصوت
                this.fingerprint.mediaDevices.audiooutput.labels.forEach(label => {
                    devices.push({
                        deviceId: 'default',
                        kind: 'audiooutput',
                        label: label,
                        groupId: 'audio-output-group'
                    });
                });
                
                return devices;
            };
        }
    }

    spoofWebGLProperties() {
        const originalGetContext = HTMLCanvasElement.prototype.getContext;
        const self = this;
        
        HTMLCanvasElement.prototype.getContext = function(contextType, contextAttributes) {
            const context = originalGetContext.call(this, contextType, contextAttributes);
            
            if (contextType.includes('webgl') && context) {
                const originalGetParameter = context.getParameter;
                
                context.getParameter = function(pname) {
                    if (pname === 37445) { // UNMASKED_VENDOR_WEBGL
                        return self.fingerprint.webgl.vendor;
                    }
                    if (pname === 37446) { // UNMASKED_RENDERER_WEBGL
                        return self.fingerprint.webgl.renderer;
                    }
                    if (pname === 7938) { // VERSION
                        return self.fingerprint.webgl.version;
                    }
                    if (pname === 35724) { // SHADING_LANGUAGE_VERSION
                        return self.fingerprint.webgl.shadingLanguage;
                    }
                    
                    return originalGetParameter.call(this, pname);
                };
            }
            
            return context;
        };
    }

    spoofAudioProperties() {
        if (window.AudioContext || window.webkitAudioContext) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            const originalAudioContext = AudioContext;
            
            window.AudioContext = function() {
                const context = new originalAudioContext();
                
                Object.defineProperty(context, 'sampleRate', {
                    get: () => this.fingerprint.audio.sampleRate,
                    configurable: false
                });
                
                return context;
            };
            
            window.AudioContext.prototype = originalAudioContext.prototype;
        }
    }

    spoofPluginProperties() {
        // Plugins
        Object.defineProperty(navigator, 'plugins', {
            get: () => ({
                length: this.fingerprint.plugins.length,
                item: (index) => this.fingerprint.plugins[index],
                namedItem: (name) => this.fingerprint.plugins.find(p => p.name === name),
                refresh: () => {},
                [Symbol.iterator]: function* () {
                    for (let plugin of this.fingerprint.plugins) {
                        yield plugin;
                    }
                }
            }),
            configurable: false
        });
        
        // MimeTypes
        Object.defineProperty(navigator, 'mimeTypes', {
            get: () => ({
                length: this.fingerprint.mimeTypes.length,
                item: (index) => this.fingerprint.mimeTypes[index],
                namedItem: (type) => this.fingerprint.mimeTypes.find(m => m.type === type),
                [Symbol.iterator]: function* () {
                    for (let mimeType of this.fingerprint.mimeTypes) {
                        yield mimeType;
                    }
                }
            }),
            configurable: false
        });
    }

    startRotation() {
        // تدوير البصمة كل 5-15 دقيقة
        this.rotationInterval = setInterval(() => {
            this.rotateFingerprint();
        }, (5 + Math.random() * 10) * 60 * 1000);
    }

    rotateFingerprint() {
        console.log('🔄 تدوير بصمة المتصفح...');
        
        // توليد بصمة جديدة
        this.generateFingerprint();
        
        // إعادة التطبيق
        this.applyFingerprint();
        
        // تسجيل النشاط
        this.logRotation();
    }

    setupProtection() {
        // حماية من اكتشاف التلاعب
        this.protectAgainstDetection();
        
        // حماية من فحص الخصائص
        this.protectPropertyInspection();
    }

    protectAgainstDetection() {
        // حماية من اكتشاف أن الخصائص غير قابلة للتعديل
        const originalDefineProperty = Object.defineProperty;
        
        Object.defineProperty = function(obj, prop, descriptor) {
            if (obj === navigator && ['userAgent', 'platform', 'plugins'].includes(prop)) {
                return obj; // تجاهل محاولات التعديل
            }
            return originalDefineProperty.call(this, obj, prop, descriptor);
        };
    }

    protectPropertyInspection() {
        // جعل الخصائص تبدو طبيعية عند الفحص
        Object.preventExtensions(navigator);
        Object.seal(navigator);
        
        // إخفاء الدليل على التلاعب
        delete navigator.__proto__.webdriver;
        delete window.__proto__.chrome;
    }

    logRotation() {
        const logEntry = {
            timestamp: new Date().toISOString(),
            fingerprintId: this.fingerprint.fingerprintId,
            userAgent: this.fingerprint.userAgent.substring(0, 50) + '...'
        };
        
        try {
            const rotations = JSON.parse(localStorage.getItem('v12_fingerprint_rotations') || '[]');
            rotations.unshift(logEntry);
            if (rotations.length > 20) rotations.pop();
            localStorage.setItem('v12_fingerprint_rotations', JSON.stringify(rotations));
        } catch (e) {
            // تجاهل الأخطاء
        }
    }

    getFingerprintSummary() {
        return {
            id: this.fingerprint.fingerprintId,
            userAgent: this.fingerprint.userAgent,
            platform: this.fingerprint.platform,
            screen: `${this.fingerprint.screen.width}x${this.fingerprint.screen.height}`,
            timezone: this.fingerprint.timezone,
            cores: this.fingerprint.hardwareConcurrency,
            memory: this.fingerprint.deviceMemory + 'GB'
        };
    }
}

// تشغيل نظام البصمة المتقدم
const advancedFingerprint = new AdvancedFingerprint();

// تصدير ملخص البصمة للاستخدام الخارجي
window.getFingerprintSummary = () => advancedFingerprint.getFingerprintSummary();