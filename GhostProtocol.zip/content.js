// نظام التخفي والتفاعل الذكي
class AdvancedInteraction {
    constructor() {
        this.isActive = false;
        this.stealthMode = true;
        this.userBehavior = {};
        this.init();
    }

    init() {
        this.loadSettings();
        this.analyzeEnvironment();
        this.startStealthEngine();
        
        // تنشيط بعد تحميل الصفحة
        setTimeout(() => {
            this.isActive = true;
            this.startInteractionCycle();
        }, 2000);
    }

    loadSettings() {
        // تحميل إعدادات التخفي من localStorage
        try {
            const settings = JSON.parse(localStorage.getItem('v12_stealth_settings')) || {};
            this.stealthMode = settings.enabled !== false;
            this.userBehavior = settings.behavior || {};
        } catch (e) {
            this.stealthMode = true;
        }
    }

    analyzeEnvironment() {
        // تحليل البيئة الحالية
        this.siteType = this.detectSiteType();
        this.riskLevel = this.assessRiskLevel();
        
        console.log(`🔍 تم تحليل: ${this.siteType} | مستوى الخطورة: ${this.riskLevel}`);
    }

    detectSiteType() {
        const url = window.location.hostname;
        
        if (url.includes('youtube.com')) return 'youtube';
        if (url.includes('a-ads.com')) return 'ads';
        if (url.includes('google.com')) return 'search';
        if (url.includes('facebook.com') || url.includes('twitter.com')) return 'social';
        
        return 'general';
    }

    assessRiskLevel() {
        // تقييم مستوى خطورة الاكتشاف
        let risk = 0;
        
        // عوامل زيادة الخطورة
        if (navigator.webDriver === true) risk += 2;
        if (window.chrome && window.chrome.loadTimes) risk += 1;
        if (navigator.plugins.length === 0) risk += 1;
        if (window.document.documentElement.getAttribute('webdriver')) risk += 2;
        
        // عوامل حسب نوع الموقع
        if (this.siteType === 'youtube') risk += 1;
        if (this.siteType === 'ads') risk += 2;
        
        return Math.min(risk, 5); // 0-5
    }

    startStealthEngine() {
        if (!this.stealthMode) return;
        
        // 1. إخفاء WebDriver
        Object.defineProperty(navigator, 'webdriver', { get: () => false });
        
        // 2. تعديل User Agent بشكل ديناميكي
        this.spoofUserAgent();
        
        // 3. تعطيل WebRTC لمنع تسريب IP
        this.disableWebRTC();
        
        // 4. إخفاء خصائص Chrome
        this.hideChromeProperties();
        
        // 5. تشويش بصمة Canvas
        this.spoofCanvasFingerprint();
        
        // 6. تشويش بصمة WebGL
        this.spoofWebGLFingerprint();
    }

    spoofUserAgent() {
        const agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        ];
        
        const newUA = agents[Math.floor(Math.random() * agents.length)];
        Object.defineProperty(navigator, 'userAgent', {
            get: () => newUA,
            configurable: false
        });
    }

    disableWebRTC() {
        if (window.RTCPeerConnection) {
            window.RTCPeerConnection = undefined;
            window.webkitRTCPeerConnection = undefined;
            window.mozRTCPeerConnection = undefined;
        }
    }

    hideChromeProperties() {
        if (window.chrome) {
            Object.defineProperty(window, 'chrome', {
                value: undefined,
                configurable: false
            });
        }
    }

    spoofCanvasFingerprint() {
        const originalToDataURL = HTMLCanvasElement.prototype.toDataURL;
        HTMLCanvasElement.prototype.toDataURL = function(type, encoderOptions) {
            const ctx = this.getContext('2d');
            if (ctx && this.width > 0 && this.height > 0) {
                // إضافة نقطة عشوائية صغيرة
                ctx.fillStyle = `rgba(${Math.floor(Math.random() * 255)}, 
                                      ${Math.floor(Math.random() * 255)}, 
                                      ${Math.floor(Math.random() * 255)}, 0.001)`;
                ctx.fillRect(0, 0, 1, 1);
            }
            return originalToDataURL.call(this, type, encoderOptions);
        };
    }

    spoofWebGLFingerprint() {
        const originalGetContext = HTMLCanvasElement.prototype.getContext;
        HTMLCanvasElement.prototype.getContext = function(contextType, contextAttributes) {
            const context = originalGetContext.call(this, contextType, contextAttributes);
            
            if (contextType.includes('webgl') && context) {
                const originalGetParameter = context.getParameter;
                context.getParameter = function(pname) {
                    if (pname === 37446) { // UNMASKED_RENDERER_WEBGL
                        const renderers = [
                            'ANGLE (Intel(R) UHD Graphics 630 Direct3D11 vs_5_0 ps_5_0)',
                            'ANGLE (NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0)',
                            'ANGLE (AMD Radeon RX 6700 XT Direct3D11 vs_5_0 ps_5_0)'
                        ];
                        return renderers[Math.floor(Math.random() * renderers.length)];
                    }
                    return originalGetParameter.call(this, pname);
                };
            }
            
            return context;
        };
    }

    startInteractionCycle() {
        if (!this.isActive) return;
        
        // دورات تفاعل ذكية حسب نوع الموقع
        switch (this.siteType) {
            case 'youtube':
                this.setupYouTubeBehavior();
                break;
            case 'ads':
                this.setupAdBehavior();
                break;
            default:
                this.setupGeneralBehavior();
        }
        
        // مراقبة مستمرة لاكتشاف البوتات
        this.startBotDetectionMonitor();
    }

    setupYouTubeBehavior() {
        // سلوك متقدم لمشاهدة اليوتيوب
        
        // 1. تخطي الإعلانات بذكاء
        this.setupAdSkipIntelligence();
        
        // 2. تفاعلات واقعية مع الفيديو
        this.setupVideoInteractions();
        
        // 3. حركات ماوس طبيعية
        this.startNaturalMouseMovements();
        
        // 4. قراءة التعليقات والتفاعل معها
        this.setupCommentInteraction();
    }

    setupAdSkipIntelligence() {
        // تخطي إعلانات يوتيوب بذكاء
        const skipButtons = [
            '.ytp-ad-skip-button',
            '.ytp-ad-skip-button-modern',
            '.videoAdUiSkipButton',
            'button[aria-label*="تخطي"]',
            'button[aria-label*="Skip"]'
        ];
        
        setInterval(() => {
            if (!this.isActive) return;
            
            skipButtons.forEach(selector => {
                const button = document.querySelector(selector);
                if (button && this.isElementVisible(button)) {
                    // انتظار عشوائي قبل التخطي (كالإنسان)
                    const waitTime = 2000 + Math.random() * 4000;
                    
                    setTimeout(() => {
                        if (this.isElementVisible(button)) {
                            this.simulateHumanClick(button);
                        }
                    }, waitTime);
                }
            });
            
            // إغلاق الإعلانات المنبثقة
            const closeButtons = [
                '.ytp-ad-overlay-close-button',
                'button[aria-label*="إغلاق"]',
                'button[aria-label*="Close"]'
            ];
            
            closeButtons.forEach(selector => {
                const button = document.querySelector(selector);
                if (button && this.isElementVisible(button)) {
                    setTimeout(() => {
                        this.simulateHumanClick(button);
                    }, 1000 + Math.random() * 2000);
                }
            });
        }, 3000);
    }

    setupVideoInteractions() {
        // تفاعلات واقعية مع مشغل الفيديو
        const video = document.querySelector('video');
        if (!video) return;
        
        // استماع لأحداث الفيديو
        video.addEventListener('play', () => this.onVideoPlay());
        video.addEventListener('pause', () => this.onVideoPause());
        
        // جدولة تفاعلات عشوائية
        setInterval(() => {
            if (!this.isActive || video.paused) return;
            
            const actions = [
                () => this.adjustVolume(),
                () => this.seekRandomly(video),
                () => this.toggleSubtitles(),
                () => this.changePlaybackSpeed()
            ];
            
            if (Math.random() > 0.85) { // 15% فرصة
                const action = actions[Math.floor(Math.random() * actions.length)];
                action();
            }
        }, 15000 + Math.random() * 30000);
    }

    onVideoPlay() {
        // تفاعلات عند تشغيل الفيديو
        setTimeout(() => {
            if (Math.random() > 0.7) {
                this.simulateLikeAction();
            }
        }, 10000 + Math.random() * 20000);
    }

    onVideoPause() {
        // سلوك عند إيقاف الفيديو
        setTimeout(() => {
            this.simulateScrollDuringPause();
        }, 3000 + Math.random() * 5000);
    }

    simulateLikeAction() {
        const likeButtons = [
            'button[aria-label*="إعجاب"]',
            'button[aria-label*="Like"]',
            '#like-button',
            'ytd-toggle-button-renderer'
        ];
        
        likeButtons.forEach(selector => {
            const button = document.querySelector(selector);
            if (button && this.isElementVisible(button)) {
                this.simulateHumanClick(button);
            }
        });
    }

    simulateScrollDuringPause() {
        window.scrollBy({
            top: (Math.random() > 0.5 ? 1 : -1) * (50 + Math.random() * 150),
            behavior: 'smooth'
        });
    }

    adjustVolume() {
        const volumeBtn = document.querySelector('.ytp-mute-button');
        if (volumeBtn && Math.random() > 0.8) {
            this.simulateHumanClick(volumeBtn);
        }
    }

    seekRandomly(video) {
        if (!video.duration) return;
        
        const progressBar = document.querySelector('.ytp-progress-bar');
        if (progressBar) {
            const rect = progressBar.getBoundingClientRect();
            const randomPosition = Math.random();
            const clickX = rect.left + rect.width * randomPosition;
            const clickY = rect.top + rect.height / 2;
            
            this.simulateClickAt(clickX, clickY);
        }
    }

    toggleSubtitles() {
        const subsBtn = document.querySelector('.ytp-subtitles-button');
        if (subsBtn && Math.random() > 0.9) {
            this.simulateHumanClick(subsBtn);
        }
    }

    changePlaybackSpeed() {
        const speedBtn = document.querySelector('.ytp-settings-button');
        if (speedBtn && Math.random() > 0.95) {
            this.simulateHumanClick(speedBtn);
            
            setTimeout(() => {
                const speedOptions = document.querySelectorAll('.ytp-menuitem-label');
                speedOptions.forEach(option => {
                    if (option.textContent.includes('Speed') || option.textContent.includes('سرعة')) {
                        this.simulateHumanClick(option);
                        
                        setTimeout(() => {
                            const speeds = document.querySelectorAll('.ytp-menuitem');
                            if (speeds.length > 0) {
                                const randomSpeed = speeds[Math.floor(Math.random() * speeds.length)];
                                this.simulateHumanClick(randomSpeed);
                            }
                        }, 500);
                    }
                });
            }, 1000);
        }
    }

    setupAdBehavior() {
        // سلوك واقعي لمشاهدة الإعلانات
        this.simulateAdViewing();
        this.startRandomScrolling();
        this.simulateMouseActivity();
    }

    simulateAdViewing() {
        // محاكاة مشاهدة إعلان
        setInterval(() => {
            if (!this.isActive) return;
            
            // تمرير عشوائي
            window.scrollBy({
                top: (Math.random() > 0.5 ? 1 : -1) * (30 + Math.random() * 120),
                behavior: 'smooth'
            });
            
            // حركة ماوس عشوائية
            this.simulateRandomMouseMove();
            
        }, 4000 + Math.random() * 6000);
    }

    startRandomScrolling() {
        // تمرير عشوائي خلال الجلسة
        setInterval(() => {
            if (!this.isActive || Math.random() > 0.7) return;
            
            const scrollable = document.documentElement.scrollHeight - window.innerHeight;
            if (scrollable > 0) {
                const target = Math.random() * scrollable;
                window.scrollTo({
                    top: target,
                    behavior: 'smooth'
                });
            }
        }, 10000 + Math.random() * 20000);
    }

    simulateMouseActivity() {
        // نشاط ماوس مستمر
        setInterval(() => {
            if (!this.isActive) return;
            
            const elements = document.querySelectorAll('a, button, img, [href]');
            if (elements.length > 0) {
                const randomElement = elements[Math.floor(Math.random() * elements.length)];
                if (this.isElementVisible(randomElement)) {
                    this.simulateMouseHover(randomElement);
                }
            }
        }, 5000 + Math.random() * 10000);
    }

    setupGeneralBehavior() {
        // سلوك عام للمواقع
        this.startGeneralInteractions();
        this.simulateReadingBehavior();
        this.setupFormInteractions();
    }

    startGeneralInteractions() {
        setInterval(() => {
            if (!this.isActive) return;
            
            const actions = [
                () => this.randomScroll(),
                () => this.simulateClickOnLink(),
                () => this.hoverOverInteractive(),
                () => this.simulateTypingInForm()
            ];
            
            if (Math.random() > 0.6) {
                const action = actions[Math.floor(Math.random() * actions.length)];
                action();
            }
        }, 8000 + Math.random() * 12000);
    }

    simulateReadingBehavior() {
        // محاكاة قراءة المحتوى
        setInterval(() => {
            if (!this.isActive || Math.random() > 0.8) return;
            
            const paragraphs = document.querySelectorAll('p, article, .content');
            if (paragraphs.length > 0) {
                const randomPara = paragraphs[Math.floor(Math.random() * paragraphs.length)];
                if (this.isElementVisible(randomPara)) {
                    this.simulateReadingOfParagraph(randomPara);
                }
            }
        }, 15000 + Math.random() * 25000);
    }

    simulateReadingOfParagraph(element) {
        const rect = element.getBoundingClientRect();
        const startY = Math.max(0, rect.top);
        const endY = Math.min(window.innerHeight, rect.bottom);
        
        // حركة عين بطيئة على النص
        for (let i = 0; i < 5; i++) {
            setTimeout(() => {
                const y = startY + (endY - startY) * (i / 5);
                const x = rect.left + Math.random() * rect.width;
                
                this.createMouseEvent('mousemove', x, y);
            }, i * 500);
        }
    }

    setupFormInteractions() {
        // تفاعل ذكي مع النماذج
        document.addEventListener('focusin', (e) => {
            if (!this.isActive || !this.stealthMode) return;
            
            if (e.target.matches('input[type="text"], input[type="email"], textarea')) {
                this.simulateHumanTyping(e.target);
            }
        });
    }

    startNaturalMouseMovements() {
        // حركات ماوس طبيعية غير خطية
        setInterval(() => {
            if (!this.isActive) return;
            
            const path = this.generateNaturalMousePath();
            this.executeMousePath(path);
        }, 3000 + Math.random() * 7000);
    }

    generateNaturalMousePath() {
        const path = [];
        const steps = 5 + Math.floor(Math.random() * 10);
        
        let lastX = Math.random() * window.innerWidth;
        let lastY = Math.random() * window.innerHeight;
        
        for (let i = 0; i < steps; i++) {
            const angle = Math.random() * Math.PI * 2;
            const distance = 20 + Math.random() * 80;
            
            const x = lastX + Math.cos(angle) * distance;
            const y = lastY + Math.sin(angle) * distance;
            
            path.push({
                x: Math.max(0, Math.min(window.innerWidth, x)),
                y: Math.max(0, Math.min(window.innerHeight, y))
            });
            
            lastX = x;
            lastY = y;
        }
        
        return path;
    }

    executeMousePath(path) {
        path.forEach((point, index) => {
            setTimeout(() => {
                this.createMouseEvent('mousemove', point.x, point.y);
            }, index * 100);
        });
    }

    setupCommentInteraction() {
        // تفاعل مع قسم التعليقات
        setInterval(() => {
            if (!this.isActive || Math.random() > 0.9) return;
            
            const commentsSection = document.querySelector('#comments');
            if (commentsSection) {
                // التمرير إلى التعليقات
                commentsSection.scrollIntoView({ behavior: 'smooth' });
                
                // قراءة بعض التعليقات
                setTimeout(() => {
                    const comments = document.querySelectorAll('#content-text');
                    if (comments.length > 0) {
                        const randomComments = [];
                        for (let i = 0; i < Math.min(3, comments.length); i++) {
                            randomComments.push(comments[Math.floor(Math.random() * comments.length)]);
                        }
                        
                        randomComments.forEach((comment, idx) => {
                            setTimeout(() => {
                                this.simulateMouseMovement(comment);
                            }, idx * 2000);
                        });
                    }
                }, 2000);
            }
        }, 30000 + Math.random() * 60000);
    }

    startBotDetectionMonitor() {
        // مراقبة مستمرة لاكتشاف أنظمة البوتات
        setInterval(() => {
            this.checkForBotDetection();
        }, 10000);
    }

    checkForBotDetection() {
        const detectionSignals = [
            () => document.querySelector('.bot-detection, .captcha, #recaptcha'),
            () => document.body.innerText.includes('bot') || document.body.innerText.includes('automated'),
            () => window.location.href.includes('challenge') || window.location.href.includes('verify'),
            () => document.cookie.includes('bot_check') || document.cookie.includes('suspicious')
        ];
        
        const isDetected = detectionSignals.some(signal => signal());
        
        if (isDetected) {
            console.warn('⚠️ تم اكتشاف إشارات نظام بوت! تنفيذ إجراءات الطوارئ...');
            this.executeEvasionProtocol();
        }
    }

    executeEvasionProtocol() {
        // إجراءات طارئة للتهرب من الاكتشاف
        
        // 1. تغيير نمط السلوك فجأة
        this.changeBehaviorPattern();
        
        // 2. إضافة تأخيرات طويلة
        this.isActive = false;
        
        setTimeout(() => {
            this.isActive = true;
            this.rotateStealthParameters();
        }, 30000 + Math.random() * 60000);
        
        // 3. تغيير User Agent
        this.spoofUserAgent();
        
        // 4. إعادة تحميل الصفحة إذا لزم
        if (Math.random() > 0.5) {
            setTimeout(() => {
                window.location.reload();
            }, 10000 + Math.random() * 20000);
        }
    }

    changeBehaviorPattern() {
        // تغيير نمط السلوك بشكل جذري
        this.userBehavior = {
            mouseSpeed: 0.5 + Math.random(),
            scrollFrequency: 0.3 + Math.random() * 0.7,
            interactionRate: 0.2 + Math.random() * 0.8
        };
    }

    rotateStealthParameters() {
        // تدوير معاملات التخفي
        console.log('🔄 تدوير معاملات التخفي...');
        
        // إعادة تطبيق إجراءات التخفي
        this.startStealthEngine();
    }

    // ===== دوال المساعدة =====
    
    simulateRandomMouseMove() {
        const x = Math.random() * window.innerWidth;
        const y = Math.random() * window.innerHeight;
        this.createMouseEvent('mousemove', x, y);
    }

    simulateMouseHover(element) {
        const rect = element.getBoundingClientRect();
        const x = rect.left + rect.width / 2;
        const y = rect.top + rect.height / 2;
        
        this.createMouseEvent('mouseover', x, y);
        this.createMouseEvent('mousemove', x, y);
        
        setTimeout(() => {
            this.createMouseEvent('mouseout', x, y);
        }, 1000 + Math.random() * 2000);
    }

    simulateMouseMovement(element) {
        const rect = element.getBoundingClientRect();
        const steps = 3;
        
        for (let i = 0; i < steps; i++) {
            setTimeout(() => {
                const x = rect.left + Math.random() * rect.width;
                const y = rect.top + Math.random() * rect.height;
                this.createMouseEvent('mousemove', x, y);
            }, i * 200);
        }
    }

    simulateHumanClick(element) {
        const rect = element.getBoundingClientRect();
        const x = rect.left + rect.width / 2;
        const y = rect.top + rect.height / 2;
        
        setTimeout(() => this.createMouseEvent('mousedown', x, y), 0);
        setTimeout(() => this.createMouseEvent('mouseup', x, y), 50 + Math.random() * 50);
        setTimeout(() => this.createMouseEvent('click', x, y), 100 + Math.random() * 50);
    }

    simulateClickAt(x, y) {
        this.createMouseEvent('mousedown', x, y);
        setTimeout(() => this.createMouseEvent('mouseup', x, y), 50);
        setTimeout(() => this.createMouseEvent('click', x, y), 100);
    }

    createMouseEvent(type, x, y) {
        const event = new MouseEvent(type, {
            view: window,
            bubbles: true,
            cancelable: true,
            clientX: x,
            clientY: y
        });
        
        document.elementFromPoint(x, y)?.dispatchEvent(event);
    }

    isElementVisible(element) {
        if (!element) return false;
        
        const rect = element.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth) &&
            rect.width > 0 &&
            rect.height > 0
        );
    }

    randomScroll() {
        const scrollable = document.documentElement.scrollHeight - window.innerHeight;
        if (scrollable > 0) {
            const target = Math.random() * scrollable;
            window.scrollTo({
                top: target,
                behavior: 'smooth'
            });
        }
    }

    simulateClickOnLink() {
        const links = document.querySelectorAll('a[href]:not([href^="#"])');
        if (links.length > 0) {
            const link = links[Math.floor(Math.random() * links.length)];
            if (this.isElementVisible(link) && Math.random() > 0.9) {
                this.simulateHumanClick(link);
            }
        }
    }

    hoverOverInteractive() {
        const interactive = document.querySelectorAll('button, [role="button"], [tabindex]');
        if (interactive.length > 0) {
            const element = interactive[Math.floor(Math.random() * interactive.length)];
            if (this.isElementVisible(element)) {
                this.simulateMouseHover(element);
            }
        }
    }

    simulateTypingInForm() {
        const inputs = document.querySelectorAll('input[type="text"], input[type="email"], textarea');
        if (inputs.length > 0 && Math.random() > 0.95) {
            const input = inputs[Math.floor(Math.random() * inputs.length)];
            this.simulateHumanTyping(input);
        }
    }

    simulateHumanTyping(input) {
        const sampleTexts = [
            "مرحبا",
            "شكرا",
            "test123",
            "hello world",
            "تجربة كتابة"
        ];
        
        const text = sampleTexts[Math.floor(Math.random() * sampleTexts.length)];
        let typed = '';
        
        input.focus();
        
        for (let i = 0; i < text.length; i++) {
            setTimeout(() => {
                typed += text[i];
                input.value = typed;
                
                input.dispatchEvent(new Event('input', { bubbles: true }));
                
                if (Math.random() > 0.9) {
                    setTimeout(() => {
                        typed = typed.slice(0, -1);
                        input.value = typed;
                        
                        setTimeout(() => {
                            typed += text[i];
                            input.value = typed;
                        }, 100 + Math.random() * 200);
                    }, 50);
                }
            }, i * (80 + Math.random() * 120));
        }
    }
}

// تشغيل النظام المتقدم
const advancedInteraction = new AdvancedInteraction();

// الاحتفاظ بوظيفة forceInteraction الأصلية
function forceInteraction() {
    if (window.location.host.includes('youtube.com')) {
        const skip = document.querySelector('.ytp-ad-skip-button, .ytp-ad-skip-button-modern');
        if (skip) skip.click();

        const video = document.querySelector('video');
        if (video && video.paused) {
            video.muted = true;
            video.play().catch(() => {
                const playBtn = document.querySelector('.ytp-play-button, .ytp-large-play-button');
                if (playBtn) playBtn.click();
            });
        }
    } else {
        const amt = (Math.random() > 0.5 ? 1 : -1) * (Math.floor(Math.random() * 150) + 50);
        window.scrollBy({ top: amt, behavior: 'smooth' });
    }
}

// تنفيذ دوري (لكن أقل تكراراً عند تفعيل النظام المتقدم)
if (window.location.protocol.startsWith('http')) {
    const interval = advancedInteraction.stealthMode ? 8000 : 4000;
    setInterval(() => {
        if (advancedInteraction.isActive) {
            forceInteraction();
        }
    }, interval);
}